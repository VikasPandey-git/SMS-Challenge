export interface SMSdata {
    id: number;
    city: string;
    start_date: string;
    end_date: string;
    price: string;
    color: string;
    status: string;
  }
  