import {Injectable} from '@angular/core';
import {Observable} from 'rxjs';
import {SMSdata} from './SMSdata';
import {HttpClient} from '@angular/common/http'

@Injectable({providedIn: 'root'})
export class DataServiceService {

constructor(private http: HttpClient) {}

// Service for fetching data from DB
getSmsData():Observable<SMSdata[]>{ 
         return this.http.get<SMSdata[]>('http://localhost:3000/fetchData');    
  };
} 
