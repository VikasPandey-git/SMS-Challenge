
import {Component} from '@angular/core';
import {SMSdata} from './SMSdata';
import {DataServiceService} from './data-service.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'SMS-App';
  // settin default params
  tableData:any;
  smsData:any;
  page=1;
  page1=1;
  page2=2;
  page3=3;
  pageSize=10;
  sortOrder='';
  sortColumn='';
  selectedStartDate='';
  selectedEndDate='';

  // Injecting dependency service
  constructor(public service: DataServiceService) {}

  // Method for populating table content
 displayTable() {

  //Sorting Data
      var result=this.sortData(this.smsData,this.sortColumn,this.sortOrder);
         
  // Filtering data by date
  if(this.selectedStartDate!='' || this.selectedEndDate!='' ){
    result= result.filter((item)=>{
      var startDate=new Date(item.start_date);
      var endDate=new Date(item.end_date);
     
      return (startDate>(new Date(this.selectedStartDate)) && endDate<(new Date(this.selectedEndDate)))

    });}
  // Fetching page corresponding data  
   
    result=result.slice((this.page - 1) * this.pageSize, this.page* this.pageSize );
   
    this.tableData=result;

 }
 
  ngOnInit(){
    // Calling services to fetch data from DB during app load.
    this.service.getSmsData().subscribe((result)=>{
      this.smsData=result;
      
      this.displayTable();
     });
    
}

// Pagination logic
traversePage(pageNo){
  
  if(pageNo == "nxt" && this.page3 <=1000){
    this.page1++;
    this.page2++;
    this.page3++;
    this.page=this.page1;
    
    this.displayTable();
  }
  else if(pageNo == "pre" && this.page1 > 1){
    this.page3--;
    this.page2--;
    this.page1--;
    this.page=this.page1;

    this.displayTable();
  }
  else if(parseInt(pageNo)>0){
    this.page=parseInt(pageNo);
    this.displayTable();
  }
  else{
    return;
  }
  
}
compare = (v1: any, v2: any) => v1 < v2 ? -1 : v1 > v2 ? 1 : 0;
// Sort Method for sorting table data based on selected column and order type
sortData(data, column, direction){
  if (direction === '' || column === '') {
    return data;
  } 
  else if(column=='start_date'|| column=='end_date') {
    return [...data].sort((a, b) => {
      const res = this.compare(new Date(a[column]), new Date(b[column]));
      return direction === 'asc' ? res : -res;
    });
  }
  else {
    return [...data].sort((a, b) => {
      const res = this.compare(a[column], b[column]);
      return direction === 'asc' ? res : -res;
    });
  }
}

//Sort Event handler. Displays the sorted data in Table as per selected column
onSort(columnName){
if(this.sortColumn==columnName && this.sortOrder =='asc')
  this.sortOrder='desc';

else if(this.sortColumn==columnName && this.sortOrder=='desc')
  this.sortOrder='asc';
 
else
  {
    this.sortColumn=columnName;
    this.sortOrder='asc';
  }
this.displayTable();
}

// Filter Method to populate the data based on date filters.
filterByDate(startDate,endDate){

  this.selectedStartDate=startDate;
  this.selectedEndDate=endDate;

  this.displayTable();
}

//class closure
}

  


