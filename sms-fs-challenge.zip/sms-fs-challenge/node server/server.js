const exp= require('express');
const mongoose= require('mongoose');
const { stringify } = require('querystring');
const cors= require('cors');

const app= exp();

// middleware functions
app.use(cors());
app.use(exp.json());

//connecting to database
mongoose.connect('mongodb://localhost/SMS_Challenge')
.then(()=>console.log('Connected to DB...'))
.catch((err)=>console.log('Error Occured: ',err));

//startin express server
app.listen(3000,()=>console.log('Server listening on port 3000...'));

// Handlin the http request.

var myData = mongoose.model('users', new mongoose.Schema({'id':Number,
'city':String,
'start_date':String,
'end_date':String,
'price':String,
'status':String,
'color':String
}));

app.get('/fetchData',async(req,res)=>{
    var pageNumber= parseInt(req.query.pageNumber);
    var pageSize = parseInt(req.query.pageSize);
   var output= await myData.find()
.skip((pageNumber-1)*pageSize)
.limit(pageSize);
console.log('Output data :',output);
res.send(output);

});